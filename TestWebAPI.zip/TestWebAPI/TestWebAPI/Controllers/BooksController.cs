﻿using Microsoft.AspNetCore.Mvc;
using TestBal;
using TestWebAPI;

namespace TestWebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class BooksController : Controller
    {
        PersonBal bal = new PersonBal();
        // GET: api/books
        [HttpGet(Name = "GetBooks")]    
        public IActionResult GetAllPeople()
        {
            
            return Ok(bal.getPersonDetails());
        }
    }
}
