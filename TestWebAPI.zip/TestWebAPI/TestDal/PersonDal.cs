﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestModel;

namespace TestDal
{
    public  class PersonDal
    {
        public List<PersonModel>  _people=new List<PersonModel>();
        public PersonDal()
        {
            _people.Add(new PersonModel
            {
                Name = "Jane",
                Age = 23,
                Books = new List<Book>
                {
                    new Book { Name = "Hamlet", Type = "Hardcover" },
                    new Book { Name = "Wuthering Heights", Type = "Paperback" }
                }
            }); 
                _people.Add(new PersonModel
                {
                    Name = "Charlotte",
                    Age = 14,
                    Books = new List<Book>
                {
                    new Book { Name = "Hamlet", Type = "Paperback" }
                }
                });
            _people.Add(new PersonModel
            {
                Name = "Max",
                Age = 25,
                Books = new List<Book>
                {
                    new Book { Name = "React: The Ultimate Guide", Type = "Hardcover" },
                    new Book { Name = "Gulliver's Travels", Type = "Hardcover" },
                    new Book { Name = "Jane Eyre", Type = "Paperback" },
                    new Book { Name = "Great Expectations", Type = "Hardcover" }
                }
            });
            _people.Add(new PersonModel
            {
                Name = "William",
                Age = 15,
                Books = new List<Book>
                {
                    new Book { Name = "Great Expectations", Type = "Hardcover" }
                }
            });
            _people.Add(new PersonModel
            {
                Name = "Charles",
                Age = 17,
                Books = new List<Book>
                {
                    new Book { Name = "Little Red Riding Hood", Type = "Hardcover" },
                    new Book { Name = "The Hobbit", Type = "Ebook" }
                }
            });
        }
        public List<PersonModel> getPersonDetails()
        {
            return _people;

        }
    }
}
